/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg2021variabel;

/**
 *
 * @author ruffi
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double alas = 10;
        double tinggi =33;
        double Luas;
        
        Luas = alas * tinggi/2;
        System.out.println("Alas: "+alas);
        System.out.println("Tinggi: "+tinggi);
        System.out.println("Luasnya adalah "+Luas);
    }
    
}
